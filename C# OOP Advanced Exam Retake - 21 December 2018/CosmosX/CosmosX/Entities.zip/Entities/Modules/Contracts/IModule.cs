﻿using CosmosX.Entities.CommonContracts;
namespace CosmosX.Entities.Modules.Contracts
{
    public interface IModule : IIdentifiable { }
}