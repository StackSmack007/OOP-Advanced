using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

public class Tests
{
    EnergyRepository energyRepository;

    [SetUp]
    public void Setup()
    {
        energyRepository = new EnergyRepository();
    }

    [Test]
    public void ConstructorInitialisesAndExists()
    {
        ProviderController providerControler = new ProviderController(energyRepository);
        Assert.NotNull(providerControler, "ProviderController was not created properly");
        Assert.That(((ProviderController)providerControler).Entities.Count == 0, "Entities not set to zero");
    }

    [TestCase("Pressure 40 100")]
    [TestCase("Solar 80 100")]
    [TestCase("Standart 80 100")]
    public void RegisterRegistersProperly(string input)
    {
        List<string> arguments = input.Split().ToList();

        var providerControler = new ProviderController(energyRepository);
        string actualMessage = providerControler.Register(arguments);
        string expectedMessage = $"Successfully registered {arguments[0]}Provider";
        Assert.AreEqual(expectedMessage, actualMessage, "Output message differs from expected!");
        int addedEntities = providerControler.Entities.Count;
        Assert.AreEqual(1, addedEntities, "Provider is not added to pool!");
    }


}
