﻿namespace _02.KingSGambit.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
