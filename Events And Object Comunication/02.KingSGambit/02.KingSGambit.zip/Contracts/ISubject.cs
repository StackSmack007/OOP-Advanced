﻿namespace _02.KingSGambit.Contracts
{
   public interface ISubject : INameable, IKillable { }
}