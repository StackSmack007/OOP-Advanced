﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2KingSGambit.Models
{
   public class Footman
    {
        public Footman(string name)
        {
            Name = name;
        }

        public string Name { get; }



    }
}
