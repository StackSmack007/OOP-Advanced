﻿using System.Collections.Generic;
using System.Linq;

namespace Problem2KingSGambit.Models
{

   public class RoyalGuard
    {
        public RoyalGuard(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }

  
    }
}