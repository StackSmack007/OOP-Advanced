﻿namespace _07InfernoInfinity.Contracts
{
    public  interface IAttributteRequest
    {
      void  Execute();
    }
}