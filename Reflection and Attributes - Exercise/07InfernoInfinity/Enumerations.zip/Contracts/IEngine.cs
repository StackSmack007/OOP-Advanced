﻿namespace _07InfernoInfinity.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
