﻿namespace _07InfernoInfinity.Enumerations
{
    public enum Clarity
    {
        Chipped = 1, Regular = 2, Perfect = 5, Flawless = 10
        //•	Chipped (increases each stat by 1)
        //•	Regular (increases each stat by 2)
        //•	Perfect (increases each stat by 5)
        //•	Flawless (increases each stat by 10)
    }
}
