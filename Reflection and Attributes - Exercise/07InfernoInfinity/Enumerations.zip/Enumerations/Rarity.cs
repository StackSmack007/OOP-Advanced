﻿namespace _07InfernoInfinity.Enumerations
{
    public enum Rarity
    {
        Common = 1, Uncommon = 2, Rare = 3, Epic = 5
        //•	Common (increases damage x1)
        //•	Uncommon (increases damage x2)
        //•	Rare (increases damage x3)
        //•	Epic (increases damage x5)
    }
}
