﻿namespace _07InfernoInfinity.Models.Gems
{
    public class Amethyst : Gem
    {
        public Amethyst(string clarityType) : base(2, 8, 4, clarityType) { }
    }
}