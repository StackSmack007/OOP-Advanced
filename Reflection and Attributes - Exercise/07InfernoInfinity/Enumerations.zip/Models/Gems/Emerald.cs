﻿namespace _07InfernoInfinity.Models.Gems
{
    public class Emerald : Gem
    {
        public Emerald(string clarityType) : base(1, 4, 9, clarityType) { }
    }
}