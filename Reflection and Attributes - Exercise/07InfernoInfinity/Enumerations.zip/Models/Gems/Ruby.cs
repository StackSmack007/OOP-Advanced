﻿namespace _07InfernoInfinity.Models.Gems
{
    public class Ruby : Gem
    {
        public Ruby(string clarityType) : base(7, 2, 5, clarityType) { }
    }
}