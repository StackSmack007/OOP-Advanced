﻿namespace _07InfernoInfinity.Models.Weapons
{
    public class Axe : Weapon
    {
        public Axe(string rarity, string name) : base(rarity, name, 4, 5, 10) { }
    }
}