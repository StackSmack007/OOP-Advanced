﻿namespace _07InfernoInfinity.Models.Weapons
{
    public  class Knife : Weapon
    {
        public Knife(string rarity, string name) : base(rarity, name, 2, 3, 4) { }
    }
}