﻿using NUnit.Framework;
using StorageMaster.Entities.Vehicles;
using System;
using System.Linq;
using System.Reflection;

namespace StorageMester.BusinessLogic.Tests
{
    [TestFixture]
    public class StructureTests
    {
        [Test]
        public void VehicleClassExist()
        {
            //Искам от тука да проверя има ли клас на име Vehicle ако има да си го asign-ne към някаква променлива
            //Ако няма да каже таз променлива е null и толкова

            Type type = typeof(Vehicle);
            //Ей така работи, проблем няма обаче ако си изтрия класа Vehicle и го няма не получавам null за type ами
            //Compile Time error и не бачка ич

            var type1 = Assembly.GetExecutingAssembly().GetTypes().FirstOrDefault(x => x.Name == "Vehicle");
            //Ей така би работило ако това го направя в класа StorageMaster обаче тука това е винаги null
            //Сега тука има много опции GetCallingAssembly, GetEntryAssembly обаче която и да избера някак си не се разбира StorageMaster и винаги дава null

            Type type2 = Type.GetType("StorageMaster.Entities.Vehicles.Vehicle");
            //Ей така би работило ако това го направя в класа StorageMaster обаче тука това е винаги null

            //Идеята е да направя проверка има ли такъв клас или няма








            //  Type type2 = Type.GetType("StorageMaster.Entities.Vehicles.Vehicle");
            //
            //  Console.WriteLine("sdsad");

        }







    }
}
