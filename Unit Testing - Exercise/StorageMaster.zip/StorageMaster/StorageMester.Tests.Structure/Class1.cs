﻿using System;

namespace StorageMester.Tests.Structure
{
    public class Class1
    {
    }
}
